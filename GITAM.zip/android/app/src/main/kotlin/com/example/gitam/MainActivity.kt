package com.example.gitam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
